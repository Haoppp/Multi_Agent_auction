a=[(90,1)]
for key,value in a:
    print(key,value)
b = {'gg':1,'pp':2}
print(list(b.keys()))
print(a[-1])
for i in range(0,1):
    print(i)
c= [1,2,3,4]
for i,j in enumerate(c):
    print(i,j)
d= []
print(2/3-1)