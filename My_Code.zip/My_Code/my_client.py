import socket
import math
import random
import collections

class myAuctionClient(object):
    """A client for bidding with the AucionRoom"""
    def __init__(self, host="localhost", port=8020, mybidderid=None, verbose=False):
        self.verbose = verbose
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((host,port))
        forbidden_chars = set(""" '".,;:{}[]()""")
        if mybidderid:
            if len(mybidderid) == 0 or any((c in forbidden_chars) for c in mybidderid):
                print("""mybidderid cannot contain spaces or any of the following: '".,;:{}[]()!""")
                raise ValueError
            self.mybidderid = mybidderid
        else:
            self.mybidderid = raw_input("Input team / player name : ").strip()  # this is the only thing that distinguishes the clients
            while len(self.mybidderid) == 0 or any((c in forbidden_chars) for c in self.mybidderid):
              self.mybidderid = raw_input("""You input an empty string or included a space  or one of these '".,;:{}[]() in your name which is not allowed (_ or / are all allowed)\n for example Emil_And_Nischal is okay\nInput team / player name: """).strip()
        self.sock.send(self.mybidderid.encode("utf-8"))

        data = self.sock.recv(5024).decode('utf_8')
        x = data.split(" ")
        if self.verbose:
            print("Have received response of %s" % ' '.join(x))
        if(x[0] != "Not" and len(data) != 0):
          self.numberbidders = int(x[0])
          if self.verbose:
              print("Number of bidders: %d" % self.numberbidders)
          self.numtypes = int(x[1])
          if self.verbose:
              print("Number of types: %d" % self.numtypes)
          self.numitems = int(x[2])
          if self.verbose:
              print("Items in auction: %d" % self.numitems)
          self.maxbudget = int(x[3])
          if self.verbose:
              print("Budget: %d" % self.maxbudget)
          self.neededtowin = int(x[4])
          if self.verbose:
              print("Needed to win: %d" % self.neededtowin)
          self.order_known = "True" == x[5]
          if self.verbose:
              print("Order known: %s" % self.order_known)
          self.auctionlist = []
          self.winnerpays = int(x[6])
          if self.verbose:
              print("Winner pays: %d" % self.winnerpays)
          self.values = {}
          self.artists = {}
          order_start = 7
          if self.neededtowin > 0:
              self.values = None
              for i in range(7, 7+(self.numtypes*2), 2):
                  self.artists[x[i]] = int(x[i+1])
                  order_start += 2
              if self.verbose:
                  print("Item types: %s" % str(self.artists))
          else:
              for i in range(7, 7+(self.numtypes*3), 3):
                  self.artists[x[i]] = int(x[i+1])
                  self.values[x[i]] = int(x[i+2])
                  order_start += 3
              if self.verbose:
                  print("Item types: %s" % str(self.artists))
                  print ("Values: %s" % str(self.values))

          if self.order_known:
              for i in range(order_start, order_start+self.numitems):
                  self.auctionlist.append(x[i])
              if self.verbose:
                  print("Auction order: %s" % str(self.auctionlist))

        self.sock.send('connected '.encode("utf-8"))

        data = self.sock.recv(5024).decode('utf_8')
        x = data.split(" ")
        if x[0] != 'players':
            print("Did not receive list of players!")
            raise IOError
        if len(x) != self.numberbidders + 2:
            print("Length of list of players received does not match numberbidders!")
            raise IOError
        if self.verbose:
         print("List of players: %s" % str(' '.join(x[1:])))

        self.players = []

        for player in range(1, self.numberbidders + 1):
          self.players.append(x[player])

        self.sock.send('ready '.encode("utf-8"))

        self.standings = {name: {artist : 0 for artist in self.artists} for name in self.players}
        for name in self.players:
          self.standings[name]["money"] = self.maxbudget

    def play_auction(self):
        winnerarray = []
        winneramount = []
        done = False
        while not done:
            data = self.sock.recv(5024).decode('utf_8')
            x = data.split(" ")
            if x[0] != "done":
                if x[0] == "selling":
                    currentitem = x[1]
                    if not self.order_known:
                        self.auctionlist.append(currentitem)
                    if self.verbose:
                        print("Item on sale is %s" % currentitem)
                    bid = self.determinebid(self.numberbidders, self.neededtowin, self.artists, self.values, len(winnerarray), self.auctionlist, winnerarray, winneramount, self.mybidderid, self.players, self.standings, self.winnerpays)
                    if self.verbose:
                        print("Bidding: %d" % bid)
                    self.sock.send(str(bid).encode("utf-8"))
                    data = self.sock.recv(5024).decode('utf_8')
                    x = data.split(" ")
                    if x[0] == "draw":
                        winnerarray.append(None)
                        winneramount.append(0)
                    if x[0] == "winner":
                        winnerarray.append(x[1])
                        winneramount.append(int(x[3]))
                        self.standings[x[1]][currentitem] += 1
                        self.standings[x[1]]["money"] -= int(x[3])
            else:
                done = True
                if self.verbose:
                    if self.mybidderid in x[1:-1]:
                        print("I won! Hooray!")
                    else:
                        print("Well, better luck next time...")
        self.sock.close()

    def determinebid(self, numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays):
        '''You have all the variables and lists you could need in the arguments of the function,
        these will always be updated and relevant, so all you have to do is use them.
        Write code to make your bot do a lot of smart stuff to beat all the other bots. Good luck,
        and may the games begin!'''

        '''
        numberbidders is an integer displaying the amount of people playing the auction game.

        wincondition is an integer. A postiive integer means that whoever gets that amount of a single type
        of item wins, whilst 0 means each itemtype will have a value and the winner will be whoever accumulates the
        highest total value before all items are auctioned or everyone runs out of funds.

        artists will be a dict of the different item types as keys with the total number of that type on auction as elements.

        values will be a dict of the item types as keys and the type value if wincondition == 0. Else value == None.

        rd is the current round in 0 based indexing.

        itemsinauction is a list where at index "rd" the item in that round is being sold is displayed. Note that it will either be as long as the sum of all the number of the items (as in "artists") in which case the full auction order is pre-announced and known, or len(itemsinauction) == rd+1, in which case it only holds the past and current items, the next item to be auctioned is unknown.

        winnerarray is a list where at index "rd" the winner of the item sold in that round is displayed.

        winneramount is a list where at index "rd" the amount of money paid for the item sold in that round is displayed.

        example: I will now construct a sentence that would be correct if you substituted the outputs of the lists:
        In round 5 winnerarray[4] bought itemsinauction[4] for winneramount[4] pounds/dollars/money unit.

        mybidderid is your name: if you want to reference yourself use that.

        players is a list containing all the names of the current players.

        standings is a set of nested dictionaries (standings is a dictionary that for each person has another dictionary
        associated with them). standings[name][artist] will return how many paintings "artist" the player "name" currently has.
        standings[name]['money'] (remember quotes for string, important!) returns how much money the player "name" has left.

            standings[mybidderid] is the information about you.
            I.e., standings[mybidderid]['money'] is the budget you have left.

        winnerpays is an integer representing which bid the highest bidder pays. If 0, the highest bidder pays their own bid,
        but if 1, the highest bidder instead pays the second highest bid (and if 2 the third highest, ect....). Note though that if you win, you always pay at least 1 (even if the second-highest was 0).

        Don't change any of these values, or you might confuse your bot! Just use them to determine your bid.
        You can also access any of the object variables defined in the constructor (though again don't change these!), or declare your own to save state between determinebid calls if you so wish.

        determinebid should return your bid as an integer. Note that if it exceeds your current budget (standings[mybidderid]['money']), the auction server will simply set it to your current budget.

        Good luck!
        '''

        # Game 1: First to buy wincondition of any artist wins, highest bidder pays own bid, auction order known.
        if (wincondition > 0) and (winnerpays == 0) and self.order_known:
            return self.first_bidding_strategy(numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays)

        # Game 2: First to buy wincondition of any artist wins, highest bidder pays own bid, auction order not known.
        if (wincondition > 0) and (winnerpays == 0) and not self.order_known:
            return self.second_bidding_strategy(numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays)

        # Game 3: Highest total value wins, highest bidder pays own bid, auction order known.
        if (wincondition == 0) and (winnerpays == 0) and self.order_known:
            return self.third_bidding_strategy(numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays)

        # Game 4: Highest total value wins, highest bidder pays second highest bid, auction order known.
        if (wincondition == 0) and (winnerpays == 1) and self.order_known:
            return self.fourth_bidding_strategy(numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays)

        # Though you will only be assessed on these four cases, feel free to try your hand at others!
        # Otherwise, this just returns a random bid.
        return self.random_bid(standings[mybidderid]['money'])

    def random_bid(self, budget):
        """Returns a random bid between 1 and left over budget."""
        return int(budget*random.random()+1)

    def get_position(self, itemsinaction, nth, artist = 'all'):# get the positions for every types of paints and then return the position of the first paints that occurs nth times in announced auction order.
        pica_posS = [i for i in range(len(itemsinaction)) if itemsinaction[i]=='Picasso']
        vanG_posS = [i for i in range(len(itemsinaction)) if itemsinaction[i]=='Van_Gogh']
        remb_posS = [i for i in range(len(itemsinaction)) if itemsinaction[i]=='Rembrandt']
        daV_posS = [i for i in range(len(itemsinaction)) if itemsinaction[i]=='Da_Vinci']

        pos_list = [pica_posS,vanG_posS,remb_posS,daV_posS]
        valid_art_index = [index for index in range(len(pos_list)) if len(pos_list[index]) >= nth]

        if len(valid_art_index) != 0:
            valid_pos = []
            for index in valid_art_index:
                valid_pos.append(pos_list[index][nth-1])
            if artist == 'all':
                return min(valid_pos)
            else:
                if artist == 'Picasso' and (0 in valid_art_index):
                    return pos_list[0][nth-1]
                elif artist == 'Van_Gogh' and (1 in valid_art_index):
                    return pos_list[1][nth-1]
                elif artist == 'Rembrandt' and (2 in valid_art_index):
                    return pos_list[2][nth-1]
                elif artist == 'Da_Vinci' and (3 in valid_art_index):
                    return pos_list[3][nth-1]
                else:
                    return len(itemsinaction)+1
        else:
            return len(itemsinaction)-1

    def get_dynamic_paint_bidprice(self, concerned_artist, current_count_dict,budget,standing,mybidderid,needtowin):# bidding strategy for observe rounds in second game
        dic = current_count_dict
        price_dic = {}
        if list(dic.keys()) == concerned_artist:
            for artist in dic.keys():
                price_dic[artist] = round((dic[artist]) / sum(dic.values()) * (budget/(needtowin-standing[mybidderid][artist]))) # change the bid according to your current budget

            return price_dic
        else:
            for artist in dic.keys():# dispose the situation that paints of one of those four artist is less than 5 and removed from concerned artists
                if artist not in concerned_artist:
                    price_dic[artist] = 0
                    del dic[artist]

            for artist in dic.keys():
                price_dic[artist] = round((dic[artist])/sum(dic.values())*(budget/(needtowin-standing[mybidderid][artist]))) # equally assign total values for remain artist first 5 paints

            return price_dic

    def check_storage(self, standings, players,current_item,mybidderid):# check in current round, whether there are players have four of this type of item, and if it does, return thier name and current balance
        player_dic = {}
        for player in players:
            if standings[player][current_item] == 4:
                # print(player, ' have four ', current_item , ' and will win if get this one.')
                    player_dic[player] = standings[player]['money']

        if mybidderid in player_dic.keys():# when I have 4 paints
            return 1
        else:
            return player_dic

    def dealwith_4paints(self, danger_name, standings,mybidderid,players):# function used to deal with other players that has 4 paints of a artist
        players_list = [player for player in players]
        players_list.remove(mybidderid)
        other_players_index = [i for i in range(len(players_list)) if players_list[i] in danger_name.keys()]

        for index in other_players_index:
            del players_list[index]

        if len(players_list) > 0 : # always used in multiple players
            max_bid = max(danger_name.values())
            othsremin_list = []
            if max_bid < standings[mybidderid]['money']:
                remain = standings[mybidderid]['money'] - max_bid
                for player in players_list:
                    othsremin_list.append(standings[player]['money']-max_bid) # compute other players (balance - max_bid) and compare it with mine, if others are larger, then they will more willing to pay this fee
                if remain > max(othsremin_list):
                    return (max_bid + 1)
                else:
                    return 1
            else:
                return 1

        elif len(players_list) == 0:# every other players have 4 this type of paints
            if standings[mybidderid]['money'] < max(danger_name.values()):
                return 1

            elif standings[mybidderid]['money'] == max(danger_name.values()):
                return max(danger_name.values())

            else:
                return max(danger_name.values()) + 1

    def aggressive_strategy4all(self, ranked_artist, artists, wincondition, current_budget, standings,# function used in executing aggressive bidding in multi-agent environment for the first game
                                mybidderid,origianl_budget=True, inverse=False):  # wincondtion is the number remain needed to win
        artist_order = []
        prefer_list = []
        price_dict = {}

        if origianl_budget is True:# whether to use preset money or current budget
            budget = 1000
        else:
            budget = current_budget

        for artist in artists:
                artist_order.append(ranked_artist.index(artist))

        if inverse == False:# whether to inverse your preference for each artist
            for rank in artist_order:  # The aim of plus 1 is to avoiding the situation when I have 0 of this artist
                prefer_list.append(1 / (rank + 1))
        else:
            for rank in artist_order:  # doing inverse
                prefer_list.append((rank + 1) / (sum(artist_order) + 4))

        for artist in artists:# calculate price dictionary
            price_dict[artist] = round(budget * prefer_list[artists.index(artist)] / (wincondition - standings[mybidderid][artist]))

        return price_dict

    def check_last_round_winner(self, concerned_round, winnerarray,winneramount,artist_name):# function used to get last round winner information for a specific artist paint
        pos_list = [index for index in range(len(concerned_round)) if concerned_round[index] == artist_name]

        if len(pos_list) == 0:
            winner_info = [None, None]
            return winner_info
        if pos_list[-1] == len(concerned_round)-1 and len(pos_list)>=2:
            pos = pos_list[-2]
            winner_info = [winnerarray[pos], winneramount[pos]]
            return winner_info
        if pos_list[-1] != len(concerned_round)-1 and len(pos_list)>=2:
            pos = pos_list[-1]
            winner_info = [winnerarray[pos], winneramount[pos]]

            return winner_info
        if pos_list[-1] != len(concerned_round) - 1 and len(pos_list) == 1:
            pos = pos_list[-1]
            winner_info = [winnerarray[pos], winneramount[pos]]
            return winner_info
        if pos_list[-1] == len(concerned_round) - 1 and len(pos_list) == 1:

            winner_info = [None, None]
            return winner_info


    def aggressive_strategy4two(self,fst_paint_pos, scd_paint_pos, opponent, current_item, rd,
                                itemsinauction, winnerarray, winneramount, fst_fav_paint,
                                scd_fav_paint, standings, mybidderid, scdbiggerfst=True):# function used for price bidding in game 1 when only 2 players are involved
        if scdbiggerfst is True:#check whether first appearance of your second preferred artist is latter than your favorite artist
            scd_pos = scd_paint_pos[0]
        else:
            scd_pos = min([pos for pos in scd_paint_pos if pos >= fst_paint_pos[0] + 1])

        if rd <= fst_paint_pos[0]:# bid 199 to observe opponent strategy
            if current_item == fst_fav_paint:
                return 200 - 1
            else:
                return 0

        elif rd == fst_paint_pos[0] + 1:
            winner_info = self.check_last_round_winner(itemsinauction[:rd+1], winnerarray, winneramount, fst_fav_paint)
            if winner_info[0] == mybidderid:#If I win by bidding 199, then I would like to stick on only bidding for my favorite paint
                if current_item == fst_paint_pos:
                    return 200
                else:
                    return 0
            elif winner_info[0] == opponent:# if opponent wins by bidding 200, I would like to shift my bidding strategy
                if winner_info[1] == 200:
                    if scd_paint_pos[4] < fst_paint_pos[5] and scd_paint_pos[4] > fst_paint_pos[
                        4]:  # i only need to distribute opponent once
                        if current_item == fst_fav_paint:
                            return 200
                        elif current_item == scd_fav_paint:
                            return 160  # (1000-200)/5
                        else:
                            return 0
                    elif scd_paint_pos[4] < fst_paint_pos[6] and scd_paint_pos[4] > fst_paint_pos[
                        5]:  # i need to distribute opponent twice
                        if current_item == fst_fav_paint:
                            return 200
                        elif current_item == scd_fav_paint:
                            return 120  # (1000-400)/5
                        else:
                            return 0
                    # elif scd_paint_pos[4] < fst_paint_pos[7] and scd_paint_pos[4] > fst_paint_pos[
                    #     6]:  # i need to distribute opponent third times
                    #     if current_item == fst_fav_paint:
                    #         return 200
                    #     elif current_item == scd_fav_paint:
                    #         return 80  # (1000-600)/5
                    #     else:
                    #         return 0
                    else:
                        if current_item == fst_fav_paint:
                            return 200
                        elif current_item == scd_fav_paint:
                            return 0
                        else:
                            return 0

                elif winner_info[1] > 200:# when opponent win the item with bid beyond 200
                    if current_item == fst_fav_paint:
                        return 200
                    else:
                        return 0

            else:
                if current_item == fst_fav_paint:
                    return 200
                else:
                    return 0

        elif rd == scd_pos:
            winner_info = self.check_last_round_winner(itemsinauction[:rd+1], winnerarray, winneramount, fst_fav_paint)
            if winner_info[0] == mybidderid:
                return 0
            elif winner_info[0] == opponent:
                if winner_info[1] == 200:
                    if scd_paint_pos[4] < fst_paint_pos[5] and scd_paint_pos[4] > fst_paint_pos[
                        4]:  # i only need to distribute opponent once
                        return 160  # (1000-200)/5
                    elif scd_paint_pos[4] < fst_paint_pos[6] and scd_paint_pos[4] > fst_paint_pos[
                        5]:  # i need to distribute opponent twice
                        return 120  # (1000-400)/5
                    # elif scd_paint_pos[4] < fst_paint_pos[7] and scd_paint_pos[4] > fst_paint_pos[
                    #     6]:  # i need to distribute opponent third times
                    #     return 80  # (1000-600)/5
                    else:
                        return 0

                elif winner_info[1] > 200:
                    return 0
                else:
                    return 0
            else:
                return 0
        elif rd < scd_pos and rd > fst_paint_pos[0] + 1:
            if scd_pos > fst_paint_pos[3]:
                if rd == fst_paint_pos[1] or rd == fst_paint_pos[2] or rd == fst_paint_pos[3]:
                    return 200
                else:
                    return 0
            elif scd_pos > fst_paint_pos[2]:
                if rd == fst_paint_pos[1] or rd == fst_paint_pos[2]:
                    return 200
                else:
                    return 0
            elif scd_pos > fst_paint_pos[1]:
                if rd == fst_paint_pos[1]:
                    return 200
                else:
                    return 0
            else:
                return 0

        else:# check whether I have gained my second preferred artist paint. If it does, then I will keep bidding on it, if not, then I will only focus on my favorite one
            index_list = [i for i in range(rd) if winnerarray[i] == mybidderid]
            scd_paint_index = [index for index in index_list if itemsinauction[index] == scd_fav_paint]
            win_price = [winneramount[index] for index in scd_paint_index]
            if len(scd_paint_index) == 0:
                if current_item == fst_fav_paint:
                    return 200
                else:
                    return 0
            else:
                for key, value in [(120, 2), (160, 1)]:
                    if win_price[0] == key:
                        if standings[mybidderid][fst_fav_paint] == value:
                            if current_item == fst_fav_paint:
                                return 0
                            elif current_item == scd_fav_paint:
                                return key
                            else:
                                return 0
                        elif standings[mybidderid][fst_fav_paint] >= 0 and standings[mybidderid][fst_fav_paint] < value:
                            if current_item == fst_fav_paint:
                                return 200
                            elif current_item == scd_fav_paint:
                                return key
                            else:
                                return 0
                        else:
                            if current_item == fst_fav_paint:
                                return 0
                            elif current_item == scd_fav_paint:
                                return key
                            else:
                                return 0

    def first_bidding_strategy(self, numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays):
        """Game 1: First to buy wincondition of any artist wins, highest bidder pays own bid, auction order known."""

        # Currently just returns a random bid
        current_item = itemsinauction[rd]
        concerned_round = self.get_position(itemsinauction,numberbidders * 4 + 1,'all')# The max round we concered for auction is numberbidders * 4 + 1
        total_concerned_round_order = itemsinauction[:concerned_round + 1]

        concerned_artist = list(artists.keys())
        total_count_dic = collections.Counter(total_concerned_round_order)

        pos_dic = {}
        rank_list = [0, 1, 2, 3]

        for artist in list(artists.keys()):
            pos_dic[artist] = self.get_position(total_concerned_round_order, wincondition, artist)
        sort_pos = sorted(pos_dic.values())

        for key, value in pos_dic.items():  # get the ranked artist name list
            rank_list[sort_pos.index(value)] = key

        fst_fav_paint = rank_list[0]
        scd_fav_paint = rank_list[1]

        ranked_artist = [rank_list[0],rank_list[1],rank_list[2],rank_list[3]]

        fst_paint_pos = [self.get_position(total_concerned_round_order, i, fst_fav_paint) for i in range(1, 9)]
        scd_paint_pos = [self.get_position(total_concerned_round_order, i, scd_fav_paint) for i in range(1, 9)]
        # print('my_favorite_paint is: ',fst_fav_paint)

        for artist, number in total_count_dic.items():  # delete the artist that has less than 5 paints in concerned auction rounds.
            if number < 5:
                del concerned_artist[concerned_artist.index(artist)]

        if current_item not in concerned_artist:
            return 0

        if numberbidders == 2:
            players_name = [player for player in players]
            del players_name[players_name.index(mybidderid)]
            opponent = players_name[0]

            danger_name = self.check_storage(standings, players, current_item, mybidderid)# check whether there is some one has four of current bidded item.

            if type(danger_name) is int:  # if i have 4 of this type paints
                return standings[mybidderid]['money']

            if scd_paint_pos[0] >= fst_paint_pos[0] + 1:
                scdbiggerfst = True
            else:
                scdbiggerfst = False

            bid_price = self.aggressive_strategy4two(fst_paint_pos, scd_paint_pos, opponent, current_item, rd,
                        itemsinauction, winnerarray, winneramount, fst_fav_paint,
                        scd_fav_paint, standings, mybidderid, scdbiggerfst)
            return bid_price

        if numberbidders > 2:
            observe_nth = 3
            observe_round = self.get_position(total_concerned_round_order,observe_nth)
            if rd < observe_round:
                bid_price_dic = self.aggressive_strategy4all(ranked_artist,concerned_artist,wincondition,
                                                             standings[mybidderid]['money'],standings,mybidderid)
                return bid_price_dic[current_item]
            else:
                danger_name = self.check_storage(standings, players,current_item, mybidderid)

                if type(danger_name) is int:# if i have 4 of this type paints
                    return standings[mybidderid]['money']

                elif len(danger_name) == 0:# if there is no one has 4 this kind of paints

                    if rd > fst_paint_pos[5]:# If I get nothing in those first five round of my favorite, I would like to change to another artist
                        num = 0
                        for index in fst_paint_pos[0:6]:
                            if winnerarray[index] == mybidderid:
                                num+= 1
                        if num == 0:
                            bid_price_dic = self.aggressive_strategy4all(ranked_artist,concerned_artist,
                                                                         wincondition,standings[mybidderid]['money'],standings,
                                                                         mybidderid,origianl_budget=False,inverse=True)
                            return bid_price_dic[current_item]
                        else:
                            bid_price_dic = self.aggressive_strategy4all(ranked_artist, concerned_artist,
                                                                          wincondition,standings[mybidderid]['money'],
                                                                         standings, mybidderid,origianl_budget=False)
                            return bid_price_dic[current_item]
                    else:
                        bid_price_dic = self.aggressive_strategy4all(ranked_artist, concerned_artist, wincondition,
                                                                     standings[mybidderid]['money'], standings,
                                                                     mybidderid,origianl_budget=False)
                        return bid_price_dic[current_item]

                else:# if there is someone has 4 this kind of paints
                    return self.dealwith_4paints(danger_name, standings,mybidderid,players)

    def get_bid_price_G2(self,my_property,budget,artists, current_item,standings,mybidderid,wincondition,numberbidders,players,itemsinauction,winnerarray,winneramount):
        price_dic = {}
        all_paints_Iown = sum(my_property)

        if numberbidders == 2:
            players_list = [player for player in players]
            del players_list[players_list.index(mybidderid)]
            opponent_name = players_list[0]
            opponent_property = [standings[opponent_name]['Picasso'],
                                            standings[opponent_name]['Van_Gogh'],
                                            standings[opponent_name]['Rembrandt'],
                                            standings[opponent_name]['Da_Vinci']]
            all_paints_opponown = sum(opponent_property)

            my_target_list = []
            opponent_target_list = []
            reduce_per_counter_opponent = 0.1
            for i in range(len(my_property)):
                if my_property[i] == max(my_property):
                    my_target_list.append(list(artists.keys())[i])
            for i in range(len(opponent_property)):
                if opponent_property[i] == max(opponent_property):
                    opponent_target_list.append(list(artists.keys())[i])

            if len(my_target_list) > 1:#obtain my target list
                for artist in my_target_list:
                    if artists[artist] == max([artists[art] for art in my_target_list]):
                        my_target = artist
            else:
                 my_target = my_target_list[0]

            if len(opponent_target_list) > 1:#obtain my opponent target list
                for artist in opponent_target_list:
                    if artists[artist] == max([artists[art] for art in opponent_target_list]):
                        opponent_target = artist
            else:
                 opponent_target = opponent_target_list[0]

            if my_target == opponent_target:
                for i, artist in list(enumerate(artists.keys())):# strategy is to assign balance to each kind of paint by the number of each type of paints opponent have
                    price_dic[artist] = round((budget*(standings[opponent_name][artist]+1)/(all_paints_opponown+4))/(wincondition-opponent_property[i]))# The plus 1 is to avoid 0 situation

                if current_item == my_target:
                    winner_info = self.check_last_round_winner(itemsinauction, winnerarray, winneramount, my_target)
                    if winner_info[0] == mybidderid:
                        return winner_info[1]
                    elif winner_info[0] is None:
                        return price_dic[current_item]
                    else:
                        return round(winner_info[1] * (1 - reduce_per_counter_opponent))
                else:
                    winner_info = self.check_last_round_winner(itemsinauction, winnerarray, winneramount, current_item)
                    if winner_info[0] == mybidderid:
                        return winner_info[1]
                    else:
                        return price_dic[current_item]
            else:
                for i, artist in list(enumerate(artists.keys())):# strategy is to assign balance to each kind of paint by the number of each type of paints i have
                    price_dic[artist] = round(
                        budget * ((standings[mybidderid][artist]+1) / (all_paints_Iown+4)) / (wincondition - my_property[i]))
                return price_dic[current_item]

        elif numberbidders > 2:
            for i, artist in list(enumerate(artists.keys())):# strategy is to assign balance to each kind of paint by the number of each type of paints i have
                price_dic[artist] = round(budget*((standings[mybidderid][artist]+1)/(all_paints_Iown+4))/(wincondition-my_property[i]))
            winner_info = self.check_last_round_winner(itemsinauction, winnerarray, winneramount, current_item)
            if winner_info[0] == mybidderid:
                return winner_info[1]
            elif winner_info[0] is None:
                return price_dic[current_item]
            else:
                return price_dic[current_item]

    def second_bidding_strategy(self, numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays):
        """Game 2: First to buy wincondition of any artist wins, highest bidder pays own bid, auction order not known."""
        current_item = itemsinauction[rd]
        concerned_artist = list(artists.keys())

        for artist, number in artists.items():  # delete the artist that has less than 5 paints in concerned auction rounds.
            if number < 5:
                del concerned_artist[concerned_artist.index(artist)]

        item_displayed_dic = collections.Counter(itemsinauction)
        remain_undisplayed_dic ={}

        for artist in artists.keys():
            remain_undisplayed_dic[artist] = artists[artist] - item_displayed_dic[artist]

        if numberbidders != 2:
            observe_nth = 4
            if max(item_displayed_dic.values()) < observe_nth:# observing rounds
                bid_price_dic = self.get_dynamic_paint_bidprice(concerned_artist, remain_undisplayed_dic,standings[mybidderid]['money'],standings,mybidderid,wincondition)# get dynamic price for each paint according to their remain number need to be gained and my budget
                return bid_price_dic[current_item]

        danger_name = self.check_storage(standings,players,current_item,mybidderid)# get players name who has 4 paints

        if type(danger_name) is int:  # if i have 4 of this type paints
            return standings[mybidderid]['money']

        elif len(danger_name) == 0:  # if there is no one has 4 of this kind of paints
            my_property = [standings[mybidderid]['Picasso'],
                                        standings[mybidderid]['Van_Gogh'],
                                        standings[mybidderid]['Rembrandt'],
                                        standings[mybidderid]['Da_Vinci']]
            return self.get_bid_price_G2(my_property,standings[mybidderid]['money'],artists, current_item,standings,mybidderid,wincondition,numberbidders,players,itemsinauction,winnerarray,winneramount)

        else:  # if there is someone has 4 this kind of paints
            return self.dealwith_4paints(danger_name, standings, mybidderid, players)


    def check_myvaluePremainvalue(self, standings,rd, itemsinauction, values, artists,players,mybidderid,numberbidders):
        my_value = 0
        remain_value = 0

        for artist in artists.keys():
            my_value += standings[mybidderid][artist] * values[artist]

        for index in range(rd + 1, len(itemsinauction)):
            remain_value += values[itemsinauction[index]]

        if numberbidders == 2:
            opponent_name = players[0]
            opponent_value = 0

            for artist in artists.keys():
                opponent_value += standings[opponent_name][artist]*values[artist]

            if remain_value+my_value <= values[itemsinauction[rd]] + opponent_value:# if the remain total value plus my current value is less than my opponent current value plus value of current bidded item
                #print(mybidderid, ": if i don't get current item, i will lose game.")
                return -1
            elif my_value + values[itemsinauction[rd]] > opponent_value + remain_value:# if the remain total value plus my opponent current value is less than my current value plus value of current bidded item
                #print(mybidderid, ": if i get this item, i will win this game.")
                return 1
            else :
                return 0

        else:
            opponent_value_list = []
            value = 0

            for player in players:
                for artist in artists.keys():
                    value += standings[player][artist]* values[artist]
                opponent_value_list.append(value)

            if remain_value+my_value <= values[itemsinauction[rd]] + max(opponent_value_list):
                #print(mybidderid, ": if I don't get current item, I will lose game.")
                return [-1,opponent_value_list.index(max(opponent_value_list))]

            elif my_value + values[itemsinauction[rd]] > max(opponent_value_list) + remain_value:
                #print(mybidderid, ": if I get this item, I will win this game.")
                return [1]

            else:
                return [0]

    def dealwith_opponentvalues(self,standings, players,danger_index,mybidderid):# how to deal with opponent's critical value
        others_values_list = []
        for i in range(len(players)):
            if i != danger_index:
                others_values_list.append(standings[players[i]]['money'])

        if standings[mybidderid]['money'] > max(others_values_list):
            return 1

        else:
            return 0

    def get_sliding_pos(self,my_current_value,part_of_total_value,itemsinauction,rd,values):# function used to get item pos which could make my current value reach the total_value input
        accumulate_value =0
        pos = []
        for index in range(len(itemsinauction[rd:])):
            accumulate_value += values[itemsinauction[rd+index]]
            if my_current_value + accumulate_value >= part_of_total_value:
                pos.append(rd+index)
            else:
                continue
        if len(pos)>0:
            return pos[0]
        else:
            return None

    def third_bidding_strategy(self, numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays):
        """Game 3: Highest total value wins, highest bidder pays own bid, auction order known."""
        total_value = 0
        remain_total = 0
        my_current_value = 0
        decrease_per = 0.1
        current_item = itemsinauction[rd]
        my_current_property = [standings[mybidderid][artist] for artist in artists.keys()]

        if mybidderid in players:
            del players[players.index(mybidderid)]

        for i, my_item in enumerate(my_current_property):# my total value before exclude the current item
            my_current_value += values[list(artists.keys())[i]] * my_item

        for item in itemsinauction:
            total_value += values[item]
        for remain_item in itemsinauction[rd:len(itemsinauction)]:
            remain_total += values[remain_item]

        print("total value / numbidders:", total_value / numberbidders)
        print("my current value:", my_current_value)

        if numberbidders == 2:

            opponent_name = players[0]
            signal = self.check_myvaluePremainvalue(standings,rd, itemsinauction, values,
                                                    artists,players,mybidderid,numberbidders)# check whether someone will win if he get this item by plus his current value with current item compared with remain total value of remain items
            if signal == -1:#my opponent will win this game if he get current item
                return standings[opponent_name]['money'] + 1
            elif signal == 1:#I will win this game if I get current item
                return standings[mybidderid]['money']
            else:#No one will win this game when getting current item
                winnable_pos = self.get_sliding_pos(my_current_value, total_value/numberbidders, itemsinauction, rd, values)
                if winnable_pos is not None:
                    if winnable_pos == rd:
                        return standings[mybidderid]['money']
                    else:
                        bid_price = round((standings[mybidderid]['money']/(total_value/numberbidders-my_current_value)) * values[current_item])
                        return bid_price
                else:
                    bid_price = round((standings[mybidderid]['money'] / remain_total) * values[current_item])
                    return bid_price

        else:# when number of players bigger than 2
            minimum_value_should_gain = total_value/numberbidders # everyone should at least earn this much money if they are rational
            winnable_pos = self.get_sliding_pos(my_current_value, minimum_value_should_gain, itemsinauction, rd,values)
            half_value_bid_price = (standings[mybidderid]['money'] / (total_value / 2 - my_current_value)) * values[
                current_item]  # bid price according to half of total value minus my current value
            bid_price_for_remain = (standings[mybidderid]['money'] / remain_total) * values[
                current_item]  # bid price according to remain value

            if my_current_value < minimum_value_should_gain:
                signal = self.check_myvaluePremainvalue(standings, rd, itemsinauction, values, artists, players,
                                                        mybidderid, numberbidders)
                if signal[0] == -1:#Some one will win if he get current item
                    result = self.dealwith_opponentvalues(standings, players,signal[1],mybidderid)

                    if result == 0:# if someone else has more tolerance than me
                        if winnable_pos is not None:
                            bid_price = round((1000/(numberbidders/2)) / (minimum_value_should_gain - my_current_value) * values[current_item])
                            if bid_price > half_value_bid_price:
                                return round(half_value_bid_price)
                            else:
                                return bid_price
                        else:
                            bid_price = round(bid_price_for_remain)
                            return bid_price

                    else:# I will pay for avoiding that opponent wins
                        return standings[players[signal[1]]]['money'] + 1

                elif signal[0] == 1:# I will win if I get current item
                    return standings[mybidderid]['money']

                else:
                    if winnable_pos is not None:
                        bid_price = round((1000 / (numberbidders / 2)) / (minimum_value_should_gain - my_current_value) * values[current_item])
                        if bid_price > (standings[mybidderid]['money'] / (total_value/2)) * values[current_item]:
                            return round(half_value_bid_price)
                        else:
                            return bid_price
                    else:
                        bid_price = round(bid_price_for_remain)
                        return bid_price

            else:
                if rd == len(itemsinauction) - 1:
                    return standings[mybidderid]['money']
                else:
                    item_index = [index for index in range(len(itemsinauction[:rd])) if itemsinauction[index] == current_item]
                    if len(winnerarray[item_index[-1]]) != 0 and winnerarray[item_index[-1]] == mybidderid:
                        bid_price = round(winneramount[item_index[-1]] * (1 - decrease_per))# bid a lower price when last round I win the same item
                        return bid_price
                    else:
                        new_winnable_pos = self.get_sliding_pos(my_current_value, total_value/2 - minimum_value_should_gain, itemsinauction, rd, values)
                        signal = self.check_myvaluePremainvalue(standings, rd, itemsinauction, values, artists, players,
                                                                mybidderid, numberbidders)
                        if signal[0] == -1:  # Some one will win if he get current item
                            result = self.dealwith_opponentvalues(standings, players, signal[1], mybidderid)

                            if result == 0:  # if someone else has more tolerance than me

                                if new_winnable_pos is not None:
                                    bid_price = round(half_value_bid_price)
                                    return bid_price
                                else:
                                    bid_price = round(bid_price_for_remain)
                                    return bid_price
                            else:  # I will pay for avoiding that opponent wins
                                return standings[players[signal[1]]]['money'] + 1

                        elif signal[0] == 1:  # I will win if I get current item
                            return standings[mybidderid]['money']

                        else:
                            if new_winnable_pos is not None:
                                return round(half_value_bid_price)
                            else:
                                bid_price = round(bid_price_for_remain)
                                return bid_price

    def fourth_bidding_strategy(self, numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays):
        """Game 4: Highest total value wins, highest bidder pays second highest bid, auction order known."""
        my_current_value = 0
        total_value = 0
        remain_total = 0
        current_item = itemsinauction[rd]
        players_list = [player for player in players]
        my_current_property = [standings[mybidderid][artist] for artist in artists.keys()]
        del players_list[players_list.index(mybidderid)]

        for item in itemsinauction:
            total_value += values[item]
        for remain_item in itemsinauction[rd:len(itemsinauction)]:
            remain_total += values[remain_item]

        for i, my_item in enumerate(my_current_property):  # my total value before exclude the current item
            my_current_value += values[list(artists.keys())[i]] * my_item

        print("total value / numbidders:", total_value / numberbidders)
        print("my current value:", my_current_value)

        if numberbidders == 2:
            opponent_name = players[0]
            signal = self.check_myvaluePremainvalue(standings, rd, itemsinauction, values,
                                                    artists, players_list, mybidderid,
                                                    numberbidders)  # check whether someone will win if he get this item by plus his current value with current item compared with remain total value of remain items
            if signal == -1:
                return standings[opponent_name]['money'] + 1
            elif signal == 1:
                return standings[mybidderid]['money']
            else:
                bid_price = round((standings[mybidderid]['money'] / (total_value/2 - my_current_value)) * values[current_item])
                return bid_price

        else:
            minimum_value_should_gain = total_value / numberbidders  # everyone should at least earn this much money if they are rational
            winnable_pos = self.get_sliding_pos(my_current_value, minimum_value_should_gain, itemsinauction, rd, values)
            half_value_bid_price = (standings[mybidderid]['money'] / (total_value / 2 - my_current_value)) * values[current_item]# bid price according to half of total value minus my current value
            bid_price_for_remain = (standings[mybidderid]['money'] / remain_total) * values[current_item]# bid price according to remain value

            if my_current_value < minimum_value_should_gain:
                signal = self.check_myvaluePremainvalue(standings, rd, itemsinauction, values, artists, players_list,
                                                        mybidderid, numberbidders)
                if signal[0] == -1:  # Some one will win if he get current item
                    result = self.dealwith_opponentvalues(standings, players_list, signal[1], mybidderid)

                    if result == 0:  # if someone else has more tolerance than me
                        if winnable_pos is not None:
                            bid_price = round(
                                (1000 / (numberbidders / 2)) / (minimum_value_should_gain - my_current_value) * values[current_item])
                            if bid_price > half_value_bid_price:
                                return round(half_value_bid_price)
                            else:
                                return bid_price
                        else:
                            bid_price = round(bid_price_for_remain)
                            return bid_price

                    else:  # I will pay for avoiding that opponent wins
                        return standings[players[signal[1]]]['money'] + 1

                elif signal[0] == 1:  # I will win if I get current item
                    return standings[mybidderid]['money']

                else:
                    if winnable_pos is not None:
                        bid_price = round((1000 / (numberbidders / 2)) / (minimum_value_should_gain - my_current_value) * values[
                                current_item])
                        if bid_price > half_value_bid_price:
                            return round(half_value_bid_price)
                        else:
                            return bid_price
                    else:
                        bid_price = round(bid_price_for_remain)
                        return bid_price

            else:
                if rd == len(itemsinauction) - 1:
                    return standings[mybidderid]['money']
                else:
                    signal = self.check_myvaluePremainvalue(standings, rd, itemsinauction, values, artists, players_list,
                                                            mybidderid, numberbidders)
                    if signal[0] == -1:  # Some one will win if he get current item
                        result = self.dealwith_opponentvalues(standings, players_list, signal[1], mybidderid)

                        if result == 0:  # if someone else has more tolerance than me
                            new_winnable_pos = self.get_sliding_pos(my_current_value,
                                                                    total_value / 2 - minimum_value_should_gain,
                                                                    itemsinauction, rd, values)
                            if new_winnable_pos is not None:
                                bid_price = round(half_value_bid_price)
                                return bid_price
                            else:
                                bid_price = round(bid_price_for_remain)
                                return bid_price
                        else:  # I will pay for avoiding that opponent wins
                            return standings[players[signal[1]]]['money'] + 1

                    elif signal[0] == 1:  # I will win if I get current item
                        return standings[mybidderid]['money']

                    else:
                        new_winnable_pos = self.get_sliding_pos(my_current_value,
                                                                total_value / 2 - minimum_value_should_gain,
                                                                itemsinauction, rd, values)
                        if new_winnable_pos is not None:
                            bid_price = round(half_value_bid_price)
                            return bid_price
                        else:
                            bid_price = round(bid_price_for_remain)
                            return bid_price