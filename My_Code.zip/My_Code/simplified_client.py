import collections

def get_position(self, itemsinaction, nth,
                 artist='all'):  # get the positions for every types of paints and then return the position of the first paints that occurs nth times in announced auction order.
    pica_posS = [i for i in range(len(itemsinaction)) if itemsinaction[i] == 'Picasso']
    vanG_posS = [i for i in range(len(itemsinaction)) if itemsinaction[i] == 'Van_Gogh']
    remb_posS = [i for i in range(len(itemsinaction)) if itemsinaction[i] == 'Rembrandt']
    daV_posS = [i for i in range(len(itemsinaction)) if itemsinaction[i] == 'Da_Vinci']

    pos_list = [pica_posS, vanG_posS, remb_posS, daV_posS]
    valid_art_index = [index for index in range(len(pos_list)) if len(pos_list[index]) >= nth]

    if len(valid_art_index) != 0:
        valid_pos = []
        for index in valid_art_index:
            valid_pos.append(pos_list[index][nth - 1])
        if artist == 'all':
            return min(valid_pos)
        else:
            if artist == 'Picasso' and (0 in valid_art_index):
                return pos_list[0][nth - 1]
            elif artist == 'Van_Gogh' and (1 in valid_art_index):
                return pos_list[1][nth - 1]
            elif artist == 'Rembrandt' and (2 in valid_art_index):
                return pos_list[2][nth - 1]
            elif artist == 'Da_Vinci' and (3 in valid_art_index):
                return pos_list[3][nth - 1]
            else:
                return len(itemsinaction) + 1
    else:
        return len(itemsinaction) - 1


def check_storage(self, standings, players, current_item,
                  mybidderid):  # check in current round, whether there are players have four of this type of item, and if it does, return thier name and current balance
    player_dic = {}
    for player in players:
        if standings[player][current_item] == 4:
            # print(player, ' have four ', current_item , ' and will win if get this one.')
            player_dic[player] = standings[player]['money']

    if mybidderid in player_dic.keys():
        return 1
    else:
        return player_dic


def dealwith_4paints(self, danger_name, standings, mybidderid, players):
    players_list = [player for player in players]
    players_list.remove(mybidderid)
    other_players_index = [i for i in range(len(players_list)) if players_list[i] in danger_name.keys()]

    for index in other_players_index:
        del players_list[index]

    if len(players_list) > 0:  # always used in multiple players
        max_bid = max(danger_name.values())
        othsremin_list = []
        if max_bid < standings[mybidderid]['money']:
            remain = standings[mybidderid]['money'] - max_bid
            for player in players_list:
                othsremin_list.append(standings[player][
                                          'money'] - max_bid)  # compute other players (balance - max_bid) and compare it with mine, if others are larger, then they will more willing to pay this fee
            if remain > max(othsremin_list):
                return (max_bid + 1)
            else:
                return 1
        else:
            return 1

    elif len(players_list) == 0:  # every other players have 4 this type of paints
        if standings[mybidderid]['money'] < max(danger_name.values()):
            return 1

        elif standings[mybidderid]['money'] == max(danger_name.values()):
            return max(danger_name.values())

        else:
            return max(danger_name.values()) + 1

def aggressive_strategy4all(self, concerned_round_order, artists, wincondition, current_budget, standings, mybidderid,
                            origianl_budget=True,inverse = False):  # wincondtion is the number remain needed to win
    fstfive_index_list = []
    artist_order = []
    prefer_list = []
    price_dict = {}

    if origianl_budget is True:
        budget = 1000
    else:
        budget = current_budget

    for artist in artists:
        index = self.get_position(concerned_round_order, wincondition, artist)
        fstfive_index_list.append(index)

    sorted_list = sorted(fstfive_index_list)

    for i in range(len(fstfive_index_list)):
        if fstfive_index_list[i] != len(concerned_round_order) + 1:
            artist_order.append(sorted_list.index(fstfive_index_list[i]))
        else:
            artist_order.append(budget - 1)
    if inverse == False:
        for rank in artist_order:  # 使每一个排名都加上1从未避免100除以0的情况
            prefer_list.append(1 / (rank + 1))
    else:
        for rank in artist_order:  # 使每一个排名都加上1从未避免100除以0的情况
            prefer_list.append((rank+1)/(sum(artist_order)+4))

    for artist in artists:
        price_dict[artist] = round(
            budget * prefer_list[artists.index(artist)] / (wincondition - standings[mybidderid][artist]))
    return price_dict

def check_last_round_winner(self, concerned_round, winnerarray, winneramount,
                            artist_name):  # concerned round is total_concerned_round[:rd]
    pos_list = [index for index in range(len(concerned_round)) if concerned_round[index] == artist_name]
    pos = pos_list[-1]
    winner_info = [winnerarray[pos], winneramount[pos]]
    return winner_info

def aggressive_strategy4two(fst_paint_pos,scd_paint_pos,opponent,current_item,rd,
                            itemsinauction,winnerarray,winneramount,fst_fav_paint,
                            scd_fav_paint,standings,mybidderid,scdbiggerfst = True):

    if scdbiggerfst is True:
        scd_pos = scd_paint_pos[0]
    else:
        scd_pos = min([pos for pos in scd_paint_pos if pos >= fst_paint_pos[0]+1])

    if rd <= fst_paint_pos[0]:
        if current_item == fst_fav_paint:
            return 200 - 1
        else:
            return 0

    elif rd == fst_paint_pos[0] + 1:
        winner_info = self.check_last_round_winner(itemsinauction[:rd], winnerarray, winneramount, fst_fav_paint)
        if winner_info[0] == mybidderid:
            if current_item == fst_paint_pos:
                return 200
            else:
                return 0
        if winner_info[0] == opponent:
            if winner_info[1] == 200:
                if scd_paint_pos[4] < fst_paint_pos[5] and scd_paint_pos[4] > fst_paint_pos[
                    4]:  # i only need to distribute opponent once
                    if current_item == fst_fav_paint:
                        return 200
                    elif current_item == scd_fav_paint:
                        return 160  # (1000-200)/5
                    else:
                        return 0
                elif scd_paint_pos[4] < fst_paint_pos[6] and scd_paint_pos[4] > fst_paint_pos[
                    5]:  # i need to distribute opponent twice
                    if current_item == fst_fav_paint:
                        return 200
                    elif current_item == scd_fav_paint:
                        return 120  # (1000-400)/5
                    else:
                        return 0
                elif scd_paint_pos[4] < fst_paint_pos[6] and scd_paint_pos[4] > fst_paint_pos[
                    5]:  # i need to distribute opponent third times
                    if current_item == fst_fav_paint:
                        return 200
                    elif current_item == scd_fav_paint:
                        return 80  # (1000-600)/5
                    else:
                        return 0

            elif winner_info[1] > 200:
                if current_item == fst_fav_paint:
                    return 200
                else:
                    return 0

    elif rd == scd_pos:
        winner_info = self.check_last_round_winner(itemsinauction[:rd], winnerarray, winneramount, fst_fav_paint)
        if winner_info[0] == mybidderid:
            return 0
        if winner_info[0] == opponent:
            if winner_info[1] == 200:
                if scd_paint_pos[4] < fst_paint_pos[5] and scd_paint_pos[4] > fst_paint_pos[
                    4]:  # i only need to distribute opponent once
                    return 160  # (1000-200)/5
                elif scd_paint_pos[4] < fst_paint_pos[6] and scd_paint_pos[4] > fst_paint_pos[
                    5]:  # i need to distribute opponent twice
                    return 120  # (1000-400)/5
                elif scd_paint_pos[4] < fst_paint_pos[7] and scd_paint_pos[4] > fst_paint_pos[
                    6]:  # i need to distribute opponent third times
                    return 80  # (1000-600)/5

            elif winner_info[1] > 200:
                return 0
    elif rd < scd_pos and rd > fst_paint_pos[0] + 1:
        return 0
    elif rd > scd_pos:
        index_list = [i for i in range(rd) if winnerarray[i] == mybidderid]
        scd_paint_index = [index for index in index_list if itemsinauction[index] == scd_fav_paint]
        win_price = [winneramount[index] for index in scd_paint_index]
        if len(scd_paint_index) == 0:
            if current_item == fst_fav_paint:
                return 200
            else:
                return 0
        else:
            for key, value in [(80, 3), (120, 2), (160, 1)]:
                if win_price[0] == key:
                    if standings[mybidderid][fst_fav_paint] == value:
                        if current_item == fst_fav_paint:
                            return 0
                        elif current_item == scd_fav_paint:
                            return key
                    elif standings[mybidderid][fst_fav_paint] >= 0 and standings[mybidderid][fst_fav_paint] < value:
                        if current_item == fst_fav_paint:
                            return 200
                        elif current_item == scd_fav_paint:
                            return key
                    else:
                        if current_item == fst_fav_paint:
                            return 0
                        elif current_item == scd_fav_paint:
                            return key


def first_bidding_strategy(self, numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray,
                           winneramount, mybidderid, players, standings, winnerpays):
    """Game 1: First to buy wincondition of any artist wins, highest bidder pays own bid, auction order known."""

    # Currently just returns a random bid
    current_item = itemsinauction[rd]
    concerned_round = self.get_position(itemsinauction, numberbidders * 4 + 1,
                                        'all')  # The max round we concered for auction is numberbidders * 4 + 1
    total_concerned_round_order = itemsinauction[:concerned_round + 1]
    current_concerned_round_order = itemsinauction[rd:concerned_round + 1]

    concerned_artist = artists.keys()

    total_count_dic = collections.Counter(total_concerned_round_order)
    current_count_dic = collections.Counter(current_concerned_round_order)

    pos_dic = {}
    rank_list = [0,1,2,3]
    for artist in artists:
        pos_dic[artist] = self.get_position(total_concerned_round_order,wincondition,artist)
    sort_pos = sorted(pos_dic.values())

    for key,value in pos_dic.items():# get the ranked artist name list
        rank_list[sort_pos.index(value)] = key


    fst_fav_paint = rank_list[0]
    scd_fav_paint = rank_list[1]
    # thd_fav_paint = rank_list[2]
    # fth_fav_paint = rank_list[3]


    fst_paint_pos = [self.get_position(total_concerned_round_order, i, fst_fav_paint) for i in range(1,9)]
    scd_paint_pos = [self.get_position(total_concerned_round_order, i, scd_fav_paint) for i in range(1,9)]
    # thd_paint_pos = [self.get_position(total_concerned_round_order, i, thd_fav_paint) for i in range(1,9)]
    # fth_paint_pos = [self.get_position(total_concerned_round_order, i, fth_fav_paint) for i in range(1,9)]

    for artist, number in total_count_dic.items():  # delete the artist that has less than 5 paints in concerned auction rounds.
        if number < 5:
            del concerned_artist[artist]

    if numberbidders == 2:
        players_name = [player for player in players]
        del players_name[mybidderid]
        opponent = players_name[0]

        if scd_paint_pos[0] >= fst_paint_pos[0]+1:
            if rd <= fst_paint_pos[0]:
                if current_item == fst_fav_paint:
                    return 200-1
                else:
                    return 0

            elif rd == fst_paint_pos[0] + 1:
                winner_info = self.check_last_round_winner(itemsinauction[:rd], winnerarray, winneramount, fst_fav_paint)
                if winner_info[0] == mybidderid:
                    if current_item == fst_paint_pos:
                        return 200
                    else:
                        return 0
                if winner_info[0] == opponent:
                    if winner_info[1] == 200:
                        if scd_paint_pos[4] < fst_paint_pos[5] and scd_paint_pos[4] > fst_paint_pos[4]:# i only need to distribute opponent once
                            if current_item == fst_fav_paint:
                                return 200
                            elif current_item == scd_fav_paint:
                                return 160 #(1000-200)/5
                            else:
                                return 0
                        elif scd_paint_pos[4] < fst_paint_pos[6] and scd_paint_pos[4] > fst_paint_pos[5]:# i need to distribute opponent twice
                            if current_item == fst_fav_paint:
                                return 200
                            elif current_item == scd_fav_paint:
                                return 120  # (1000-400)/5
                            else:
                                return 0
                        elif scd_paint_pos[4] < fst_paint_pos[6] and scd_paint_pos[4] > fst_paint_pos[5]:# i need to distribute opponent third times
                            if current_item == fst_fav_paint:
                                return 200
                            elif current_item == scd_fav_paint:
                                return 80  # (1000-600)/5
                            else:
                                return 0

                    elif winner_info[1] > 200:
                        if current_item == fst_fav_paint:
                            return 200
                        else:
                            return 0

            elif rd == scd_paint_pos[0]:
                winner_info = self.check_last_round_winner(itemsinauction[:rd], winnerarray, winneramount, fst_fav_paint)
                if winner_info[0] == mybidderid:
                        return 0
                if winner_info[0] == opponent:
                    if winner_info[1] == 200:
                        if scd_paint_pos[4] < fst_paint_pos[5] and scd_paint_pos[4] > fst_paint_pos[
                            4]:  # i only need to distribute opponent once
                                return 160  # (1000-200)/5
                        elif scd_paint_pos[4] < fst_paint_pos[6] and scd_paint_pos[4] > fst_paint_pos[
                            5]:  # i need to distribute opponent twice
                                return 120  # (1000-400)/5
                        elif scd_paint_pos[4] < fst_paint_pos[7] and scd_paint_pos[4] > fst_paint_pos[
                            6]:  # i need to distribute opponent third times
                                return 80  # (1000-600)/5

                    elif winner_info[1] > 200:
                            return 0
            elif rd < scd_paint_pos[0] and rd > fst_paint_pos[0]+1:
                    return 0
            elif rd > scd_paint_pos[0]:
                index_list = [i for i in range(rd) if winnerarray[i] == mybidderid]
                scd_paint_index = [index for index in index_list if itemsinauction[index] == scd_fav_paint]
                win_price = [winneramount[index] for index in scd_paint_index]
                if len(scd_paint_index) == 0:
                    if current_item == fst_fav_paint:
                        return 200
                    else:
                        return 0
                else:
                    for key, value in [(80, 3), (120, 2), (160, 1)]:
                        if win_price[0] == key:
                            if standings[mybidderid][fst_fav_paint] == value:
                                if current_item == fst_fav_paint:
                                    return 0
                                elif current_item == scd_fav_paint:
                                    return key
                            elif standings[mybidderid][fst_fav_paint] >= 0 and standings[mybidderid][fst_fav_paint] < value:
                                if current_item == fst_fav_paint:
                                    return 200
                                elif current_item == scd_fav_paint:
                                    return key
                            else:
                                if current_item == fst_fav_paint:
                                    return 0
                                elif current_item == scd_fav_paint:
                                    return key

        else:
            scd_pos = min([pos for pos in scd_paint_pos if pos >= fst_paint_pos[0]+1])

            if rd <= fst_paint_pos[0]:
                if current_item == fst_fav_paint:
                    return 200 - 1
                else:
                    return 0

            elif rd == fst_paint_pos[0] + 1:
                winner_info = self.check_last_round_winner(itemsinauction[:rd], winnerarray, winneramount,
                                                           fst_fav_paint)
                if winner_info[0] == mybidderid:
                    if current_item == fst_paint_pos:
                        return 200
                    else:
                        return 0
                if winner_info[0] == opponent:
                    if winner_info[1] == 200:
                        if scd_paint_pos[4] < fst_paint_pos[5] and scd_paint_pos[4] > fst_paint_pos[
                            4]:  # i only need to distribute opponent once
                            if current_item == fst_fav_paint:
                                return 200
                            elif current_item == scd_fav_paint:
                                return 160  # (1000-200)/5
                            else:
                                return 0
                        elif scd_paint_pos[4] < fst_paint_pos[6] and scd_paint_pos[4] > fst_paint_pos[
                            5]:  # i need to distribute opponent twice
                            if current_item == fst_fav_paint:
                                return 200
                            elif current_item == scd_fav_paint:
                                return 120  # (1000-400)/5
                            else:
                                return 0
                        elif scd_paint_pos[4] < fst_paint_pos[6] and scd_paint_pos[4] > fst_paint_pos[
                            5]:  # i need to distribute opponent third times
                            if current_item == fst_fav_paint:
                                return 200
                            elif current_item == scd_fav_paint:
                                return 80  # (1000-600)/5
                            else:
                                return 0

                    elif winner_info[1] > 200:
                        if current_item == fst_fav_paint:
                            return 200
                        else:
                            return 0
            elif rd == scd_pos:
                winner_info = self.check_last_round_winner(itemsinauction[:rd], winnerarray, winneramount,
                                                           fst_fav_paint)
                if winner_info[0] == mybidderid:
                    return 0
                if winner_info[0] == opponent:
                    if winner_info[1] == 200:
                        if scd_paint_pos[4] < fst_paint_pos[5] and scd_paint_pos[4] > fst_paint_pos[
                            4]:  # i only need to distribute opponent once
                            return 160  # (1000-200)/5
                        elif scd_paint_pos[4] < fst_paint_pos[6] and scd_paint_pos[4] > fst_paint_pos[
                            5]:  # i need to distribute opponent twice
                            return 120  # (1000-400)/5
                        elif scd_paint_pos[4] < fst_paint_pos[6] and scd_paint_pos[4] > fst_paint_pos[
                            5]:  # i need to distribute opponent third times
                            return 80  # (1000-600)/5

                    elif winner_info[1] > 200:
                        return 0
            elif rd < scd_pos and rd > fst_paint_pos[0]+1:
                return 0
            elif rd > scd_pos:
                index_list = [i for i in range(rd) if winnerarray[i] == mybidderid]
                scd_paint_index = [index for index in index_list if itemsinauction[index] == scd_fav_paint]
                win_price = [winneramount[index] for index in scd_paint_index]
                if len(scd_paint_index) == 0:
                    if current_item == fst_fav_paint:
                        return 200
                    else:
                        return 0
                else:
                    for key, value in [(80, 3), (120, 2), (160, 1)]:
                        if win_price[0] == key:
                            if standings[mybidderid][fst_fav_paint] == value:
                                if current_item == fst_fav_paint:
                                    return 0
                                elif current_item == scd_fav_paint:
                                    return key
                            elif standings[mybidderid][fst_fav_paint] == 0:
                                if current_item == fst_fav_paint:
                                    return 200
                                elif current_item == scd_fav_paint:
                                    return key
                            else:
                                if current_item == fst_fav_paint:
                                    return 0
                                elif current_item == scd_fav_paint:
                                    return key
        # elif rd == scd_paint_pos[0] + 1:
        #     winner_info = self.check_last_round_winner(itemsinauction[:rd], winnerarray, winneramount, scd_fav_paint)
        #     if winner_info[0] == opponent:
        #         if current_item == fst_fav_paint:
        #             return 200
        #         else:
        #             return 0
        #     elif winner_info[0] is None:
        #         if scd_paint_pos[4] < fst_paint_pos[5] and scd_paint_pos[4] > fst_paint_pos[
        #             4]:  # i only need to distribute opponent once
        #             if current_item == fst_fav_paint:
        #                 return 200
        #             elif current_item == scd_fav_paint:
        #                 return 160  # (1000-200)/5
        #             else:
        #                 return 0
        #         elif scd_paint_pos[4] < fst_paint_pos[6] and scd_paint_pos[4] > fst_paint_pos[
        #             5]:  # i need to distribute opponent twice
        #             if current_item == fst_fav_paint:
        #                 return 200
        #             elif current_item == scd_fav_paint:
        #                 return 120  # (1000-400)/5
        #             else:
        #                 return 0
        #         elif scd_paint_pos[4] < fst_paint_pos[6] and scd_paint_pos[4] > fst_paint_pos[
        #             5]:  # i need to distribute opponent third times
        #             if current_item == fst_fav_paint:
        #                 return 200
        #             elif current_item == scd_fav_paint:
        #                 return 80  # (1000-600)/5
        #             else:
        #                 return 0
        #     elif winner_info[0] == mybidderid:
        #         if current_item == fst_fav_paint:
        #             return 200
        #         elif current_item == scd_fav_paint:
        #             return winner_info[1]
        #         else:
        #             return 0

            # danger_name = self.check_storage(standings, players, current_item,
            #                                  mybidderid)  # check whether there is sonme one has four of current bidded item.
            #
            # if type(danger_name) is int:  # if i have 4 of this type paints
            #     return standings[mybidderid]['money']
            #
            # elif len(danger_name) == 0:  # if there is no one has 4 this kind of paints
            #     my_property_neededtowin = [wincondition - standings[mybidderid]['Picasso'],
            #                                wincondition - standings[mybidderid]['Van_Gogh'],
            #                                wincondition - standings[mybidderid]['Rembrandt'],
            #                                wincondition - standings[mybidderid]['Da_Vinci']]  # 每一种艺术品距离自己拥有第五幅的数量
            #     my_target_list = [self.get_position(current_concerned_round_order, my_property_neededtowin[0], 'Picasso'),
            #                       self.get_position(current_concerned_round_order, my_property_neededtowin[1], 'Van_Gogh'),
            #                       self.get_position(current_concerned_round_order, my_property_neededtowin[2], 'Rembrandt'),
            #                       self.get_position(current_concerned_round_order, my_property_neededtowin[3],
            #                                         'Da_Vinci')]  # 求出每种画到达第五幅的位置
            #     target = [my_target_list.index(min(my_target_list)), min(my_target_list)]  # 最小距离能得到5个某一种画
            #
            #     if target[1] == len(current_concerned_round_order) - 1:
            #         print(
            #             "===There is impossible to win===")  # because in concerned round, none of those four paints has enough number that you need to win.
            #         return 1
            #
            #     if current_item == artists.keys()[target[
            #         0]]:  # if current item is target item, then the agent will divide all balance to remain number of target paints that it needs to win
            #         if standings[opponent][artists.keys()[target[0]]] <= standings[mybidderid][
            #             artists.keys()[target[0]]] and standings[opponent]['money'] <= standings[mybidderid]['money']:
            #             return round(standings[mybidderid]['money'] / my_property_neededtowin[target[0]])
            #         else:
            #             bid_price_dic = self.get_dynamic_paint_bidprice(concerned_artist, current_count_dic,
            #                                                             standings[mybidderid]['money'], standings,
            #                                                             mybidderid, wincondition)
            #             return bid_price_dic[itemsinauction[rd]]
            #     else:
            #         bid_price_dic = self.get_dynamic_paint_bidprice(concerned_artist, current_count_dic,
            #                                                         standings[mybidderid]['money'], standings,
            #                                                         mybidderid, wincondition)
            #         return bid_price_dic[itemsinauction[rd]]
            # else:  # if there is someone has 4 this kind of paints
            #     return self.dealwith_4paints(danger_name, standings, mybidderid, players)


    if numberbidders > 2:
        observe_nth = 2
        observe_round = self.get_position(total_concerned_round_order, observe_nth)
        if rd < observe_round:
            bid_price = self.aggressive_strategy4all(total_concerned_round_order, artists, standings[mybidderid]['money'],
                                                     wincondition)
            return bid_price
        else:
            danger_name = self.check_storage(standings, players, current_item, mybidderid)

            if type(danger_name) is int:  # if i have 4 of this type paints
                return standings[mybidderid]['money']

            elif len(danger_name) == 0:  # if there is no one has 4 this kind of paints
                bid_price_dic = self.get_dynamic_paint_bidprice(concerned_artist, current_count_dic,
                                                                standings[mybidderid]['money'], standings, mybidderid,
                                                                wincondition)
                print(bid_price_dic)
                return bid_price_dic[itemsinauction[rd]]

            else:  # if there is someone has 4 this kind of paints
                return self.dealwith_4paints(danger_name, standings, mybidderid, players)
