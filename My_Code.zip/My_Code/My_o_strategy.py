import socket
import random
import collections

class myoAuctionClient(object):
    """A client for bidding with the AucionRoom"""
    def __init__(self, host="localhost", port=8020, mybidderid=None, verbose=False):
        self.verbose = verbose
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((host,port))
        forbidden_chars = set(""" '".,;:{}[]()""")
        if mybidderid:
            if len(mybidderid) == 0 or any((c in forbidden_chars) for c in mybidderid):
                print("""mybidderid cannot contain spaces or any of the following: '".,;:{}[]()!""")
                raise ValueError
            self.mybidderid = mybidderid
        else:
            self.mybidderid = raw_input("Input team / player name : ").strip()  # this is the only thing that distinguishes the clients
            while len(self.mybidderid) == 0 or any((c in forbidden_chars) for c in self.mybidderid):
              self.mybidderid = raw_input("""You input an empty string or included a space  or one of these '".,;:{}[]() in your name which is not allowed (_ or / are all allowed)\n for example Emil_And_Nischal is okay\nInput team / player name: """).strip()
        self.sock.send(self.mybidderid.encode("utf-8"))

        data = self.sock.recv(5024).decode('utf_8')
        x = data.split(" ")
        if self.verbose:
            print("Have received response of %s" % ' '.join(x))
        if(x[0] != "Not" and len(data) != 0):
          self.numberbidders = int(x[0])
          if self.verbose:
              print("Number of bidders: %d" % self.numberbidders)
          self.numtypes = int(x[1])
          if self.verbose:
              print("Number of types: %d" % self.numtypes)
          self.numitems = int(x[2])
          if self.verbose:
              print("Items in auction: %d" % self.numitems)
          self.maxbudget = int(x[3])
          if self.verbose:
              print("Budget: %d" % self.maxbudget)
          self.neededtowin = int(x[4])
          if self.verbose:
              print("Needed to win: %d" % self.neededtowin)
          self.order_known = "True" == x[5]
          if self.verbose:
              print("Order known: %s" % self.order_known)
          self.auctionlist = []
          self.winnerpays = int(x[6])
          if self.verbose:
              print("Winner pays: %d" % self.winnerpays)
          self.values = {}
          self.artists = {}
          order_start = 7
          if self.neededtowin > 0:
              self.values = None
              for i in range(7, 7+(self.numtypes*2), 2):
                  self.artists[x[i]] = int(x[i+1])
                  order_start += 2
              if self.verbose:
                  print("Item types: %s" % str(self.artists))
          else:
              for i in range(7, 7+(self.numtypes*3), 3):
                  self.artists[x[i]] = int(x[i+1])
                  self.values[x[i]] = int(x[i+2])
                  order_start += 3
              if self.verbose:
                  print("Item types: %s" % str(self.artists))
                  print ("Values: %s" % str(self.values))

          if self.order_known:
              for i in range(order_start, order_start+self.numitems):
                  self.auctionlist.append(x[i])
              if self.verbose:
                  print("Auction order: %s" % str(self.auctionlist))

        self.sock.send('connected '.encode("utf-8"))

        data = self.sock.recv(5024).decode('utf_8')
        x = data.split(" ")
        if x[0] != 'players':
            print("Did not receive list of players!")
            raise IOError
        if len(x) != self.numberbidders + 2:
            print("Length of list of players received does not match numberbidders!")
            raise IOError
        if self.verbose:
         print("List of players: %s" % str(' '.join(x[1:])))

        self.players = []

        for player in range(1, self.numberbidders + 1):
          self.players.append(x[player])

        self.sock.send('ready '.encode("utf-8"))

        self.standings = {name: {artist : 0 for artist in self.artists} for name in self.players}
        for name in self.players:
          self.standings[name]["money"] = self.maxbudget

    def play_auction(self):
        winnerarray = []
        winneramount = []
        done = False
        while not done:
            data = self.sock.recv(5024).decode('utf_8')
            x = data.split(" ")
            if x[0] != "done":
                if x[0] == "selling":
                    currentitem = x[1]
                    if not self.order_known:
                        self.auctionlist.append(currentitem)
                    if self.verbose:
                        print("Item on sale is %s" % currentitem)
                    bid = self.determinebid(self.numberbidders, self.neededtowin, self.artists, self.values, len(winnerarray), self.auctionlist, winnerarray, winneramount, self.mybidderid, self.players, self.standings, self.winnerpays)
                    if self.verbose:
                        print("Bidding: %d" % bid)
                    self.sock.send(str(bid).encode("utf-8"))
                    data = self.sock.recv(5024).decode('utf_8')
                    x = data.split(" ")
                    if x[0] == "draw":
                        winnerarray.append(None)
                        winneramount.append(0)
                    if x[0] == "winner":
                        winnerarray.append(x[1])
                        winneramount.append(int(x[3]))
                        self.standings[x[1]][currentitem] += 1
                        self.standings[x[1]]["money"] -= int(x[3])
            else:
                done = True
                if self.verbose:
                    if self.mybidderid in x[1:-1]:
                        print("I won! Hooray!")
                    else:
                        print("Well, better luck next time...")
        self.sock.close()

    def determinebid(self, numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays):
        '''You have all the variables and lists you could need in the arguments of the function,
        these will always be updated and relevant, so all you have to do is use them.
        Write code to make your bot do a lot of smart stuff to beat all the other bots. Good luck,
        and may the games begin!'''

        '''
        numberbidders is an integer displaying the amount of people playing the auction game.

        wincondition is an integer. A postiive integer means that whoever gets that amount of a single type
        of item wins, whilst 0 means each itemtype will have a value and the winner will be whoever accumulates the
        highest total value before all items are auctioned or everyone runs out of funds.

        artists will be a dict of the different item types as keys with the total number of that type on auction as elements.

        values will be a dict of the item types as keys and the type value if wincondition == 0. Else value == None.

        rd is the current round in 0 based indexing.

        itemsinauction is a list where at index "rd" the item in that round is being sold is displayed. Note that it will either be as long as the sum of all the number of the items (as in "artists") in which case the full auction order is pre-announced and known, or len(itemsinauction) == rd+1, in which case it only holds the past and current items, the next item to be auctioned is unknown.

        winnerarray is a list where at index "rd" the winner of the item sold in that round is displayed.

        winneramount is a list where at index "rd" the amount of money paid for the item sold in that round is displayed.

        example: I will now construct a sentence that would be correct if you substituted the outputs of the lists:
        In round 5 winnerarray[4] bought itemsinauction[4] for winneramount[4] pounds/dollars/money unit.

        mybidderid is your name: if you want to reference yourself use that.

        players is a list containing all the names of the current players.

        standings is a set of nested dictionaries (standings is a dictionary that for each person has another dictionary
        associated with them). standings[name][artist] will return how many paintings "artist" the player "name" currently has.
        standings[name]['money'] (remember quotes for string, important!) returns how much money the player "name" has left.

            standings[mybidderid] is the information about you.
            I.e., standings[mybidderid]['money'] is the budget you have left.

        winnerpays is an integer representing which bid the highest bidder pays. If 0, the highest bidder pays their own bid,
        but if 1, the highest bidder instead pays the second highest bid (and if 2 the third highest, ect....). Note though that if you win, you always pay at least 1 (even if the second-highest was 0).

        Don't change any of these values, or you might confuse your bot! Just use them to determine your bid.
        You can also access any of the object variables defined in the constructor (though again don't change these!), or declare your own to save state between determinebid calls if you so wish.

        determinebid should return your bid as an integer. Note that if it exceeds your current budget (standings[mybidderid]['money']), the auction server will simply set it to your current budget.

        Good luck!
        '''

        # Game 1: First to buy wincondition of any artist wins, highest bidder pays own bid, auction order known.
        if (wincondition > 0) and (winnerpays == 0) and self.order_known:
            return self.first_bidding_strategy(numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays)

        # Game 2: First to buy wincondition of any artist wins, highest bidder pays own bid, auction order not known.
        if (wincondition > 0) and (winnerpays == 0) and not self.order_known:
            return self.second_bidding_strategy(numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays)

        # Game 3: Highest total value wins, highest bidder pays own bid, auction order known.
        if (wincondition == 0) and (winnerpays == 0) and self.order_known:
            return self.third_bidding_strategy(numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays)

        # Game 4: Highest total value wins, highest bidder pays second highest bid, auction order known.
        if (wincondition == 0) and (winnerpays == 1) and self.order_known:
            return self.fourth_bidding_strategy(numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays)

        # Though you will only be assessed on these four cases, feel free to try your hand at others!
        # Otherwise, this just returns a random bid.
        return self.random_bid(standings[mybidderid]['money'])

    def random_bid(self, budget):
        """Returns a random bid between 1 and left over budget."""
        return int(budget*random.random()+1)

    def get_position(self, itemsinaction, nth, artist = 'all'):# get the positions for every types of paints and then return the position of the first paints that occurs nth times in announced auction order.
        pica_posS = [i for i in range(len(itemsinaction)) if itemsinaction[i]=='Picasso']
        vanG_posS = [i for i in range(len(itemsinaction)) if itemsinaction[i]=='Van_Gogh']
        remb_posS = [i for i in range(len(itemsinaction)) if itemsinaction[i]=='Rembrandt']
        daV_posS = [i for i in range(len(itemsinaction)) if itemsinaction[i]=='Da_Vinci']

        pos_list = [pica_posS,vanG_posS,remb_posS,daV_posS]
        valid_art_index = [index for index in range(len(pos_list)) if len(pos_list[index]) >= nth]

        if len(valid_art_index) != 0:
            valid_pos = []
            for index in valid_art_index:
                valid_pos.append(pos_list[index][nth-1])
            if artist == 'all':
                return min(valid_pos)
            else:
                if artist == 'Picasso' and (0 in valid_art_index):
                    return pos_list[0][nth-1]
                elif artist == 'Van_Gogh' and (1 in valid_art_index):
                    return pos_list[1][nth-1]
                elif artist == 'Rembrandt' and (2 in valid_art_index):
                    return pos_list[2][nth-1]
                elif artist == 'Da_Vinci' and (3 in valid_art_index):
                    return pos_list[3][nth-1]
                else:
                    return len(itemsinaction)+1
        else:
            return len(itemsinaction)-1

    def get_dynamic_paint_bidprice(self, concerned_artist, current_count_dict,budget,standing,mybidderid,needtowin):
        dic = current_count_dict
        price_dic = {}
        if dic.keys() == concerned_artist:
            for artist in dic.keys():
                price_dic[artist] = round((dic[artist]) / sum(dic.values()) * (budget/(4*(needtowin-standing[mybidderid][artist])))) # change the bid according to the budget

            return price_dic
        else:
            for artist in dic.keys():
                if artist not in concerned_artist:
                    price_dic[artist] = 0
                    del dic[artist]

            for artist in dic.keys():
                price_dic[artist] = round((dic[artist])/sum(dic.values())*((budget/len(dic.keys()))/(needtowin-standing[mybidderid][artist]))) # equally assign total values for remain artist first 5 paints

            return price_dic

    def get_static_paint_bidprice(self, concerned_artist, total_count_dict):
        dic = total_count_dict
        price_dic = {}
        if dic.keys() == concerned_artist:
            for artist in dic.keys():
                price_dic[artist] = round((dic[artist]) / sum(dic.values())) * 50 # 50 is derived from 250*(1/5)

            return price_dic
        else:
            for artist in dic.keys():
                if artist not in concerned_artist:
                    price_dic[artist] = 0
                    del dic[artist]

            for artist in dic.keys():
                price_dic[artist] = round((dic[artist])/sum(dic.values())*((1000/len(dic.keys()))/5)) # equally assign total values for remain artist first 5 paints

            return price_dic

    def check_storage(self, standings, players,current_item,mybidderid):# check in current round, whether there are players have four of this type of item, and if it does, return thier name and current balance
        player_dic = {}
        for player in players:
            if standings[player][current_item] == 4:
                # print(player, ' have four ', current_item , ' and will win if get this one.')
                    player_dic[player] = standings[player]['money']

        if mybidderid in player_dic.keys():
            return 1
        else:
            return player_dic

    def dealwith_4paints(self, danger_name, standings,mybidderid,players):
        players_list = [player for player in players]
        players_list.remove(mybidderid)
        other_players_index = [i for i in range(len(players_list)) if players_list[i] in danger_name.keys()]

        for index in other_players_index:
            del players_list[index]

        if len(players_list) > 0 : # always used in multiple players
            max_bid = max(danger_name.values())
            othsremin_list = []
            if max_bid < standings[mybidderid]['money']:
                remain = standings[mybidderid]['money'] - max_bid
                for player in players_list:
                    othsremin_list.append(standings[player]['money']-max_bid) # compute other players (balance - max_bid) and compare it with mine, if others are larger, then they will more willing to pay this fee
                if remain > max(othsremin_list):
                    return (max_bid + 1)
                else:
                    return 1
            else:
                return 1

        elif len(players_list) == 0:# every other players have 4 this type of paints
            if standings[mybidderid]['money'] < max(danger_name.values()):
                return 1

            elif standings[mybidderid]['money'] == max(danger_name.values()):
                return max(danger_name.values())

            else:
                return max(danger_name.values()) + 1

    def aggressive_strategy4all(self, concerned_round_order, artists, wincondition, current_budget, standings,
                                mybidderid,
                                origianl_budget=True, inverse=False):  # wincondtion is the number remain needed to win
        fstfive_index_list = []
        artist_order = []
        prefer_list = []
        price_dict = {}

        if origianl_budget is True:
            budget = 1000
        else:
            budget = current_budget

        for artist in artists:
            index = self.get_position(concerned_round_order, wincondition, artist)
            fstfive_index_list.append(index)

        sorted_list = sorted(fstfive_index_list)

        for i in range(len(fstfive_index_list)):
            if fstfive_index_list[i] != len(concerned_round_order) + 1:
                artist_order.append(sorted_list.index(fstfive_index_list[i]))
            else:
                artist_order.append(budget - 1)
        if inverse == False:
            for rank in artist_order:  # 使每一个排名都加上1从未避免100除以0的情况
                prefer_list.append(1 / (rank + 1))
        else:
            for rank in artist_order:  # 使每一个排名都加上1从未避免100除以0的情况
                prefer_list.append((rank + 1) / (sum(artist_order) + 4))

        for artist in artists:
            price_dict[artist] = round(
                budget * prefer_list[artists.index(artist)] / (wincondition - standings[mybidderid][artist]))
        return price_dict

    def check_last_round_winner(self, concerned_round, winnerarray,winneramount,artist_name):# concerned round is total_concerned_round[:rd]
        pos_list = [index for index in range(len(concerned_round)) if concerned_round[index] == artist_name]
        pos = pos_list[-2]
        winner_info = [winnerarray[pos],winneramount[pos]]
        return winner_info

    def aggressive_strategy4two(self,fst_paint_pos, scd_paint_pos, opponent, current_item, rd,
                                itemsinauction, winnerarray, winneramount, fst_fav_paint,
                                scd_fav_paint, standings, mybidderid, scdbiggerfst=True):

        if scdbiggerfst is True:
            scd_pos = scd_paint_pos[0]
        else:
            scd_pos = min([pos for pos in scd_paint_pos if pos >= fst_paint_pos[0] + 1])

        if rd <= fst_paint_pos[0]:
            if current_item == fst_fav_paint:
                return 200 - 1
            else:
                return 0

        elif rd == fst_paint_pos[0] + 1:
            winner_info = self.check_last_round_winner(itemsinauction[:rd], winnerarray, winneramount, fst_fav_paint)
            if winner_info[0] == mybidderid:
                if current_item == fst_paint_pos:
                    return 200
                else:
                    return 0
            if winner_info[0] == opponent:
                if winner_info[1] == 200:
                    if scd_paint_pos[4] < fst_paint_pos[5] and scd_paint_pos[4] > fst_paint_pos[
                        4]:  # i only need to distribute opponent once
                        if current_item == fst_fav_paint:
                            return 200
                        elif current_item == scd_fav_paint:
                            return 160  # (1000-200)/5
                        else:
                            return 0
                    elif scd_paint_pos[4] < fst_paint_pos[6] and scd_paint_pos[4] > fst_paint_pos[
                        5]:  # i need to distribute opponent twice
                        if current_item == fst_fav_paint:
                            return 200
                        elif current_item == scd_fav_paint:
                            return 120  # (1000-400)/5
                        else:
                            return 0
                    elif scd_paint_pos[4] < fst_paint_pos[6] and scd_paint_pos[4] > fst_paint_pos[
                        5]:  # i need to distribute opponent third times
                        if current_item == fst_fav_paint:
                            return 200
                        elif current_item == scd_fav_paint:
                            return 80  # (1000-600)/5
                        else:
                            return 0

                elif winner_info[1] > 200:
                    if current_item == fst_fav_paint:
                        return 200
                    else:
                        return 0

        elif rd == scd_pos:
            winner_info = self.check_last_round_winner(itemsinauction[:rd], winnerarray, winneramount, fst_fav_paint)
            if winner_info[0] == mybidderid:
                return 0
            if winner_info[0] == opponent:
                if winner_info[1] == 200:
                    if scd_paint_pos[4] < fst_paint_pos[5] and scd_paint_pos[4] > fst_paint_pos[
                        4]:  # i only need to distribute opponent once
                        return 160  # (1000-200)/5
                    elif scd_paint_pos[4] < fst_paint_pos[6] and scd_paint_pos[4] > fst_paint_pos[
                        5]:  # i need to distribute opponent twice
                        return 120  # (1000-400)/5
                    elif scd_paint_pos[4] < fst_paint_pos[7] and scd_paint_pos[4] > fst_paint_pos[
                        6]:  # i need to distribute opponent third times
                        return 80  # (1000-600)/5

                elif winner_info[1] > 200:
                    return 0
        elif rd < scd_pos and rd > fst_paint_pos[0] + 1:
            return 0
        elif rd > scd_pos:
            index_list = [i for i in range(rd) if winnerarray[i] == mybidderid]
            scd_paint_index = [index for index in index_list if itemsinauction[index] == scd_fav_paint]
            win_price = [winneramount[index] for index in scd_paint_index]
            if len(scd_paint_index) == 0:
                if current_item == fst_fav_paint:
                    return 200
                else:
                    return 0
            else:
                for key, value in [(80, 3), (120, 2), (160, 1)]:
                    if win_price[0] == key:
                        if standings[mybidderid][fst_fav_paint] == value:
                            if current_item == fst_fav_paint:
                                return 0
                            elif current_item == scd_fav_paint:
                                return key
                        elif standings[mybidderid][fst_fav_paint] >= 0 and standings[mybidderid][fst_fav_paint] < value:
                            if current_item == fst_fav_paint:
                                return 200
                            elif current_item == scd_fav_paint:
                                return key
                        else:
                            if current_item == fst_fav_paint:
                                return 0
                            elif current_item == scd_fav_paint:
                                return key

    def first_bidding_strategy(self, numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays):
        """Game 1: First to buy wincondition of any artist wins, highest bidder pays own bid, auction order known."""

        # Currently just returns a random bid
        current_item = itemsinauction[rd]
        concerned_round = self.get_position(itemsinauction,numberbidders * 4 + 1,'all')# The max round we concered for auction is numberbidders * 4 + 1
        total_concerned_round_order = itemsinauction[:concerned_round + 1]
        current_concerned_round_order = itemsinauction[rd:concerned_round + 1]

        concerned_artist = artists.keys()

        total_count_dic = collections.Counter(total_concerned_round_order)
        current_count_dic = collections.Counter(current_concerned_round_order)
        fith_pos = self.get_position(total_concerned_round_order,wincondition)
        favorite_paint = itemsinauction[fith_pos]
        first_favorite_pos = self.get_position(total_concerned_round_order,1,favorite_paint)

        for artist, number in total_count_dic.items():  # delete the artist that has less than 5 paints in concerned auction rounds.
            if number < 5:
                del concerned_artist[artist]

        if numberbidders == 2:
                players_name = [player for player in players]
                del players_name[mybidderid]
                opponent = players_name[0]

                danger_name = self.check_storage(standings, players, current_item, mybidderid)# check whether there is sonme one has four of current bidded item.

                if type(danger_name) is int:  # if i have 4 of this type paints
                    return standings[mybidderid]['money']

                elif len(danger_name) == 0:  # if there is no one has 4 this kind of paints
                    my_property_neededtowin =  [wincondition-standings[mybidderid]['Picasso'],wincondition-standings[mybidderid]['Van_Gogh'],wincondition-standings[mybidderid]['Rembrandt'],wincondition-standings[mybidderid]['Da_Vinci']]# 每一种艺术品距离自己拥有第五幅的数量
                    my_target_list = [self.get_position(current_concerned_round_order,my_property_neededtowin[0],'Picasso'),self.get_position(current_concerned_round_order,my_property_neededtowin[1],'Van_Gogh'),self.get_position(current_concerned_round_order,my_property_neededtowin[2],'Rembrandt'),self.get_position(current_concerned_round_order,my_property_neededtowin[3],'Da_Vinci')]#求出每种画到达第五幅的位置
                    target = [my_target_list.index(min(my_target_list)),min(my_target_list)]#最小距离能得到5个某一种画

                    if target[1] == len(current_concerned_round_order)-1:
                        print("===There is impossible to win===")# because in concerned round, none of those four paints has enough number that you need to win.
                        return 1

                    if current_item == artists.keys()[target[0]]:#if current item is target item, then the agent will divide all balance to remain number of target paints that it needs to win
                        if standings[opponent][artists.keys()[target[0]]] <= standings[mybidderid][artists.keys()[target[0]]] and standings[opponent]['money'] <= standings[mybidderid]['money']:
                            return round(standings[mybidderid]['money']/my_property_neededtowin[target[0]])
                        else:
                            bid_price_dic = self.get_dynamic_paint_bidprice(concerned_artist, current_count_dic,
                                                                            standings[mybidderid]['money'], standings,
                                                                            mybidderid, wincondition)
                            return bid_price_dic[itemsinauction[rd]]
                    else:
                        bid_price_dic = self.get_dynamic_paint_bidprice(concerned_artist, current_count_dic,
                                                                        standings[mybidderid]['money'], standings,
                                                                        mybidderid, wincondition)
                        return bid_price_dic[itemsinauction[rd]]
                else:# if there is someone has 4 this kind of paints
                    return self.dealwith_4paints(danger_name, standings, mybidderid, players)

        if numberbidders > 2 :
            observe_nth = 2
            observe_round = self.get_position(total_concerned_round_order,observe_nth)
            if rd < observe_round:
                bid_price = self.aggressive_strategy4all(total_concerned_round_order,artists,standings[mybidderid]['money'],wincondition)
                return bid_price
            else:
                danger_name = self.check_storage(standings, players,current_item, mybidderid)

                if type(danger_name) is int:# if i have 4 of this type paints
                    return standings[mybidderid]['money']

                elif len(danger_name) == 0:# if there is no one has 4 this kind of paints
                    bid_price_dic = self.get_dynamic_paint_bidprice(concerned_artist, current_count_dic,standings[mybidderid]['money'],standings,mybidderid,wincondition)
                    print(bid_price_dic)
                    return bid_price_dic[itemsinauction[rd]]

                else:# if there is someone has 4 this kind of paints
                    return self.dealwith_4paints(danger_name, standings,mybidderid,players)


        #return self.random_bid(standings[mybidderid]['money'])
    def get_bid_price_G2(self,my_property,budget,artists, current_item,standings,mybidderid,wincondition,numberbidders,players):
        price_dic = {}
        all_paints_Iown = sum(my_property)

        if numberbidders == 2:
            players_list = [player for player in players]
            del players_list[mybidderid]
            opponent_name = players_list[0]
            opponent_property = [standings[opponent_name]['Picasso'],
                                            standings[opponent_name]['Van_Gogh'],
                                            standings[opponent_name]['Rembrandt'],
                                            standings[opponent_name]['Da_Vinci']]
            all_paints_opponown = sum(opponent_property)
            for i, artist in list(enumerate(artists.keys())):# strategy is to assign balance to each kind of paint by the number of each type of paints opponent have
                price_dic[artist] = round(budget*(standings[opponent_name][artist]/all_paints_opponown)/(wincondition-opponent_property[i]))
            return price_dic[current_item]

        elif numberbidders > 2:
            for i, artist in list(enumerate(artists.keys())):# strategy is to assign balance to each kind of paint by the number of each type of paints i have
                price_dic[artist] = round(budget*(standings[mybidderid][artist]/all_paints_Iown)/(wincondition-my_property[i]))
            return price_dic[current_item]

    def second_bidding_strategy(self, numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays):
        """Game 2: First to buy wincondition of any artist wins, highest bidder pays own bid, auction order not known."""
        current_item = itemsinauction[rd]
        max_concerned_round = numberbidders*4*4+1 # max rounds that needed for producing a winner

        if max_concerned_round > 200:
            max_concerned_round = 200

        item_displayed_dic = collections.Counter(itemsinauction)
        if max(item_displayed_dic.values()) < 3:# observing rounds
            return standings[mybidderid]['money']/(max_concerned_round-rd)
        else:
            danger_name = self.check_storage(standings,players,current_item,mybidderid)
            if type(danger_name) is int:  # if i have 4 of this type paints
                return standings[mybidderid]['money']

            elif len(danger_name) == 0:  # if there is no one has 4 of this kind of paints
                my_property = [standings[mybidderid]['Picasso'],
                                            standings[mybidderid]['Van_Gogh'],
                                            standings[mybidderid]['Rembrandt'],
                                            standings[mybidderid]['Da_Vinci']]
                return self.get_bid_price_G2(my_property,standings[mybidderid]['money'],artists, current_item,standings,mybidderid,wincondition,numberbidders,players)

            else:  # if there is someone has 4 this kind of paints
                return self.dealwith_4paints(danger_name, standings, mybidderid, players)

        # Currently just returns a random bid
        #return self.random_bid(standings[mybidderid]['money'])
    def check_myvaluePremainvalue(self, standings,rd, itemsinauction, values, artists,players,mybidderid,numberbidders):
        my_value = 0
        remain_value = 0

        for artist in artists.keys():
            my_value += standings[mybidderid][artist] * values[artist]

        for index in range(rd + 1, len(itemsinauction)):
            remain_value += values[itemsinauction[index]]

        if numberbidders == 2:
            opponent_name = players[0]
            opponent_value = 0

            for artist in artists.keys():
                opponent_value += standings[opponent_name][artist]*values[artist]

            if remain_value+my_value <= values[itemsinauction[rd]] + opponent_value:
                print(mybidderid, ": if i don't get current item, i will lose game.")
                return -1
            elif my_value + values[itemsinauction[rd]] > opponent_value + remain_value:
                print(mybidderid, ": if i get this item, i will win this game.")
                return 1
            else :
                return 0

        else:
            opponent_value_list = []
            value = 0
            for player in players:
                for artist in artists.keys():
                    value += standings[player][artist]* values[artist]
                opponent_value_list.append(value)

            if remain_value+my_value <= values[itemsinauction[rd]] + max(opponent_value_list):
                print(mybidderid, ": if I don't get current item, I will lose game.")
                return [-1,opponent_value_list.index(max(opponent_value_list))]

            elif my_value + values[itemsinauction[rd]] > max(opponent_value_list) + remain_value:
                print(mybidderid, ": if I get this item, I will win this game.")
                return [1]

            else :
                return [0]

    def get_observe_round(self,itemsinauction,nth):
        num_list = [0,0,0,0]

        for index in range(len(itemsinauction)):
            if itemsinauction[index] == 'Picasso':
                num_list[0] += 1
            elif itemsinauction[index] == 'Van_Gogh':
                num_list[1] += 1
            elif itemsinauction[index] == 'Rembrandt':
                num_list[2] += 1
            else:
                num_list[3] += 1

            if min(num_list) == nth:
                return index
            else:
                continue

    def dealwith_opponentvalues(self,standings, players,danger_index,mybidderid):
        others_values_list = []
        for i in range(len(players)):
            if i != danger_index:
                others_values_list.append(standings[players[i]]['money'])

        if standings[mybidderid]['money'] > max(others_values_list):
            return 1

        else:
            return 0

    def third_bidding_strategy(self, numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays):
        """Game 3: Highest total value wins, highest bidder pays own bid, auction order known."""
        observe_round = self.get_observe_round(itemsinauction,1)
        total_value = 0
        remain_total = 0
        decrease_per = 0.25
        current_item = itemsinauction[rd]
        if mybidderid in players:
            del players[players.index(mybidderid)]

        for item in itemsinauction:
            total_value += values[item]
        for remain_item in itemsinauction[rd:len(itemsinauction)]:
            remain_total += values[remain_item]

        if rd <= observe_round:
            if rd < 1:
                bid_price = round(1000/total_value * values[current_item])
                return bid_price
            else:
                item_index = [index for index in range(len(itemsinauction[:rd])) if itemsinauction[index] == current_item]
                if len(item_index) > 0:
                    if winnerarray[item_index[-1]] == mybidderid:
                        bid_price = round(winneramount[item_index[-1]]*(1-decrease_per))
                        return bid_price
                    else:
                        bid_price = round(1000 / total_value * values[current_item])
                        return bid_price
                else:
                    bid_price = round(1000 / total_value * values[current_item])
                    return bid_price

        else:
            if numberbidders == 2:
                item_index = [index for index in range(len(itemsinauction[:rd])) if
                              itemsinauction[index] == current_item]
                if winnerarray[item_index[-1]] == mybidderid:# if i am the winner of this item in the last round that bid this item, i would like to reduce the bidding price of it in order to make a better profit
                    bid_price = round(winneramount[item_index[-1]] * (1 - decrease_per))
                    return bid_price
                else:
                    opponent_name = players[0]
                    signal = self.check_myvaluePremainvalue(standings,rd, itemsinauction, values,
                                                            artists,players,mybidderid,numberbidders)# check whether someone will win if he get this item by plus his current value with current item compared with remain total value of remain items
                    if signal == -1:
                        return standings[opponent_name]['money'] + 1
                    elif signal == 1:
                        return standings[mybidderid]['money']
                    else:
                        bid_price = round(standings[mybidderid]['money']/remain_total * values[current_item])
                        return bid_price

            else:
                item_index = [index for index in range(len(itemsinauction[:rd])) if itemsinauction[index] == current_item]
                if winnerarray[item_index[-1]] == mybidderid:
                    bid_price = round(winneramount[item_index[-1]] * (1 - decrease_per))
                    return bid_price
                else:
                    signal = self.check_myvaluePremainvalue(standings, rd, itemsinauction, values, artists, players,
                                                            mybidderid, numberbidders)
                    if signal[0] == -1:
                        result = self.dealwith_opponentvalues(standings, players,signal[1],mybidderid)

                        if result == 0:
                            bid_price = round(standings[mybidderid]['money'] / remain_total * values[current_item])
                            return bid_price
                        else:
                            return standings[players[signal[1]]]['money'] + 1

                    elif signal[0] == 1:
                        return standings[mybidderid]['money']

                    else:
                        bid_price = round(standings[mybidderid]['money'] / remain_total * values[current_item])
                        return bid_price
        # Currently just returns a random bid
        #return self.random_bid(standings[mybidderid]['money'])

    def fourth_bidding_strategy(self, numberbidders, wincondition, artists, values, rd, itemsinauction, winnerarray, winneramount, mybidderid, players, standings, winnerpays):
        """Game 4: Highest total value wins, highest bidder pays second highest bid, auction order known."""
        observe_round = self.get_observe_round(itemsinauction, 1)
        total_value = 0
        remain_total = 0
        current_item = itemsinauction[rd]
        players_list = [player for player in players]
        del players_list[mybidderid]

        for item in itemsinauction:
            total_value += values[item]
        for remain_item in itemsinauction[rd:len(itemsinauction)]:
            remain_total += values[remain_item]

        if rd <= observe_round:
            bid_price = round(1000/total_value * values[current_item])
            return bid_price

        else:
            if numberbidders == 2:
                opponent_name = players[0]
                signal = self.check_myvaluePremainvalue(standings, rd, itemsinauction, values,
                                                        artists, players, mybidderid,
                                                        numberbidders)  # check whether someone will win if he get this item by plus his current value with current item compared with remain total value of remain items
                if signal == -1:
                    return standings[opponent_name]['money'] + 1
                elif signal == 1:
                    return standings[mybidderid]['money']
                else:
                    bid_price = round(standings[mybidderid]['money'] / remain_total * values[current_item])
                    return bid_price

            else:
                signal = self.check_myvaluePremainvalue(standings, rd, itemsinauction, values, artists, players,
                                                        mybidderid, numberbidders)
                if signal[0] == -1:
                    result = self.dealwith_opponentvalues(standings, players, signal[1], mybidderid)

                    if result == 0:
                        bid_price = round(standings[mybidderid]['money'] / remain_total * values[current_item])
                        return bid_price
                    else:
                        return standings[players[signal[1]]]['money'] + 1

                elif signal[0] == 1:
                    return standings[mybidderid]['money']

                else:
                    bid_price = round(standings[mybidderid]['money'] / remain_total * values[current_item])
                    return bid_price

        # Currently just returns a random bid
        #return self.random_bid(standings[mybidderid]['money'])