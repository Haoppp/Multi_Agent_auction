from multiprocessing import Process
from AuctionClient import AuctionClient
from AuctionServer import AuctionServer
from my_client import myAuctionClient
from My_o_strategy import myoAuctionClient
from opponent import opponentAuctionClient
import time

HOST = "localhost"
ports = 8075
numbidders = 10
neededtowin = 5
itemtypes = ['Picasso', 'Van_Gogh', 'Rembrandt', 'Da_Vinci']
#numitems = {'Picasso': 50, 'Van_Gogh' : 40, 'Rembrandt' : 30, 'Da_Vinci' : 10}
numitems = {}
auction_size = 200
budget = 1000
values = {'Picasso': 4, 'Van_Gogh' : 6, 'Rembrandt' : 8, 'Da_Vinci' : 12}
announce_order = False
winner_pays = 0

args = (HOST, ports, numbidders, neededtowin, itemtypes, numitems, auction_size, budget, values, announce_order, winner_pays
, )

verbose = False

def run_auction(host, ports, numbidders, neededtowin, itemtypes, numitems, auction_size, budget, values, announce_order, winner_pays):
    auctionroom = AuctionServer(host=host, ports=ports, numbidders=numbidders, neededtowin=neededtowin,
    itemtypes=itemtypes, numitems=numitems, auction_size=auction_size, budget=budget, values=values, announce_order=announce_order, winner_pays=winner_pays)
    auctionroom.announce_auction()
    auctionroom.run_auction()


def run_client(port, bidderid, verbose):
    bidbot = AuctionClient(port=port, mybidderid=bidderid, verbose=verbose)
    bidbot.play_auction()

def run_my_client(port,bidderid, verbose):
    bidbot = myAuctionClient(port = port, mybidderid= bidderid, verbose = verbose)
    bidbot.play_auction()

def run_my_original_client(port,bidderid, verbose):
    bidbot = myoAuctionClient(port = port, mybidderid= bidderid, verbose = verbose)
    bidbot.play_auction()

def run_opponent_client(port,bidderid, verbose):
    bidbot = opponentAuctionClient(port = port, mybidderid= bidderid, verbose = verbose)
    bidbot.play_auction()

if __name__=='__main__':
     print("Starting AuctionServer")
     auctionserver = Process(target = run_auction, args = args)
     auctionserver.start()
     time.sleep(2)
     bidbots = []

     for i in range(numbidders-2):
         p = ports + i
         name = "Test" + str(i+1)
         print("Starting AuctionClient on port %d with name %s" % (p, name))
         b = Process(target = run_client, args = (p, name, verbose, ))
         bidbots.append(b)
         b.start()
         time.sleep(1)

     # p = ports# test compete with my self
     # name = "Test1"
     # print("Starting AuctionClient on port %d with name %s" % (p, name))
     # b = Process(target=run_my_client, args=(p, name, verbose,))
     # b.start()
     # time.sleep(1)

     # p = ports# test compete with my original strategy
     # name = "Test1"
     # print("Starting AuctionClient on port %d with name %s" % (p, name))
     # b = Process(target=run_my_original_client, args=(p, name, verbose,))
     # b.start()
     # time.sleep(1)

     p = 8083# test compete with opponent strategy
     name = "Test9"
     print("Starting AuctionClient on port %d with name %s" % (p, name))
     b = Process(target=run_opponent_client, args=(p, name, verbose,))
     b.start()
     time.sleep(1)

     my_id = 'Ha0'
     my_port = 8084
     print("Starting AuctionClient on port %d with name %s" % (my_port, my_id))
     me = Process(target=run_my_client,args = (my_port,my_id, True,))
     me.start()

